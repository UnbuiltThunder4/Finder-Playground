//: [Previous Page](@previous)

//Fabio Scala
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    @State var mov = 0.0
    @State var mov1 = 0.0
    @State var mov2 = 0.0
    @State var mov3 = 0.0
    @State var fakenum = 3
    @State var canmatch = false
    @State var didmatch = false
    @State private var choice: Int = 1
    @State private var text1: Int = 0
    @State private var text2: Int = 0
    @State private var text3: Int = 0
    
    var body: some View {
        NavigationView{
            VStack {
                Image(uiImage: UIImage(named: "banner.png")!)
                    .frame(width: 10, height: 10)
                    .offset(x: 0, y: 49)
                    .scaleEffect(0.45)
                    .ignoresSafeArea()
                //Profiles
                ZStack{
                    Image(uiImage: UIImage(named: "gabbibbo.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: 0, y: -50)
                    Image(uiImage: UIImage(named: "next.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: 0, y: -50)
                    Image(uiImage: UIImage(named: "betty.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov, y: -50)
                        .animation(.easeIn, value: mov)
                    //Match icon
                    if(didmatch == true) {
                        Image(uiImage: UIImage(named: "match.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 350, height: 450)
                            .padding()
                            .offset(x: mov, y: -50)
                            .animation(.easeIn, value: mov)
                    }
                    Image(uiImage: UIImage(named: "fabio.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov1, y: -50)
                        .animation(.easeIn, value: mov1)
                    Image(uiImage: UIImage(named: "eminem.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov2, y: -50)
                        .animation(.easeIn, value: mov2)
                    Image(uiImage: UIImage(named: "antonino.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov3, y: -50)
                        .animation(.easeIn, value: mov3)
                }
                HStack {
                    Spacer()
                    //Decline button
                    Image(uiImage: UIImage(named: "X.png")!)
                        .frame(width: 80, height: 50)
                        .offset(x: -25, y: -25)
                        .onTapGesture {
                            if(fakenum == 0) {
                                mov = -500.0
                                canmatch = false
                                didmatch = false
                            }
                            if(fakenum == 1) {
                                mov1 = -500.0
                                fakenum -= 1
                                canmatch = true
                            }
                            if(fakenum == 2) {
                                mov2 = -500.0
                                fakenum -= 1
                            }
                            if(fakenum == 3) {
                                mov3 = -500.0
                                fakenum -= 1
                            }
                        }
                    //Switch View
                    if(canmatch == true) {
                        NavigationLink(destination: DialogueView(choice: $choice, text1: $text1, text2: $text2, text3: $text3)) {
                            Image(uiImage: UIImage(named: "like.png")!)
                                .frame(width: 80, height: 50)
                                .offset(x: 25, y: -25)
                        }
                        .onDisappear {
                            didmatch = true
                        }
                    }
                    else {
                        //Like button
                        Image(uiImage: UIImage(named: "like.png")!)
                            .frame(width: 80, height: 50)
                            .offset(x: 25, y: -25)
                            .onTapGesture {
                                if(fakenum == 1) {
                                    mov1 = 500.0
                                    fakenum -= 1
                                    canmatch = true
                                }
                                if(fakenum == 2) {
                                    mov2 = 500.0
                                    fakenum -= 1
                                }
                                if(fakenum == 3) {
                                    mov3 = 500.0
                                    fakenum -= 1
                                }
                            }
                    }
                    Spacer()
                }
                Spacer()
            }
        }
    }
}

struct DialogueView: View {
    @Binding var choice: Int
    @Binding var text1: Int
    @Binding var text2: Int
    @Binding var text3: Int
    
    
    var body: some View {
        NavigationView{
            VStack {
                //Little photo on top of the screen
                Image(uiImage: UIImage(named: "2 icon.png")!)
                    .frame(width: 10, height: 10)
                    .offset(x: 0, y: 85)
                    .scaleEffect(0.3)
                    .ignoresSafeArea()
                Text("Hello dear. Are you a coffee \nperson or a tea person?")
                    .padding(10)
                    .foregroundColor(.white)
                    .background(Color.gray)
                    .cornerRadius(10)
                    .offset(x: -55, y: -155)
                if(text1 == 1) {
                    //First response to first question
                    Text("Tea")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 145, y: -147)
                    Text("I'm sorry... I can't... this reminds \nme of my ex boyfriend")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -43, y: -140)
                }
                if(text1 == 2) {
                    //Second response to first question
                    Text("Coffee")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 140, y: -147)
                    Text("I'm sorry... I can't... this reminds \nme of my ex boyfriend.")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -43, y: -140)
                }
                if(text2 == 1) {
                    //First response to first question
                    Text("We're always someone's ex... \nThis is life.")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 52, y: -133)
                    Text("He was my King. He always made me laugh.\n He gifted me 3 corgis... and now he's gone.")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: 0, y: -124)
                }
                if(text2 == 2) {
                    //Second response to first question
                    Text("I know how you feel, it is hard to \novercome the end of a relationship.")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 33, y: -133)
                    Text("He was my King. He always made me laugh.\n He gifted me 3 corgis... and now he's gone.")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: 0, y: -124)
                }
                if(text3 == 1) {
                    //First response to second question
                    Text("Distract yourself, push hard on your \nhobbies, meet new people...")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 32, y: -118)
                    Spacer()
                    Text("Betty has left the chat")
                        .padding(1)
                        .offset(x: 0, y: -5)
                }
                if(text3 == 2) {
                    //Second response to second question
                    Text("I have my own problems \nalready, bye.")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 75, y: -118)
                    Spacer()
                    Text("You block Betty")
                        .padding(1)
                        .offset(x: 0, y: -5)
                }
                Spacer()
                HStack{
                    if(choice == 1) {
                        //First choice to first dialogue
                        Button {
                            text1 = 1
                            choice += 1
                        } label: {
                            Text("Tea")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to first dialogue
                        Button {
                            text1 = 2
                            choice += 1
                        } label: {
                            Text("Coffee")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                    if(choice == 2) {
                        //First choice to first dialogue
                        Button {
                            text2 = 1
                            choice += 1
                        } label: {
                            Text("Be realist")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to first dialogue
                        Button {
                            text2 = 2
                            choice += 1
                        } label: {
                            Text("Empathize")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                    if(choice == 3) {
                        //First choice to second dialogue
                        Button {
                            text3 = 1
                            choice += 1
                        } label: {
                            Text("Approach")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to second dialogue
                        Button {
                            text3 = 2
                            choice += 1
                        } label: {
                            Text("Block her")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                }
            }
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())

//: [Next Page](@next)
