//: [Previous Page](@previous)

//Alessandro Colantonio
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    @State var mov1 = 0.0
    @State var mov2 = 0.0
    @State var mov3 = 0.0
    @State var fakenum = 3
    @State var superLike = false
    @State private var choice: Int = 1
    @State private var text1: Int = 0
    @State private var text2: Int = 0
    @State private var text3: Int = 0

    var body: some View {
        NavigationView{
            VStack {
                Image(uiImage: UIImage(named: "banner.png")!)
                    .frame(width: 10, height: 10)
                    .offset(x: 0, y: 49)
                    .scaleEffect(0.45)
                    .ignoresSafeArea()
                //Profiles
                ZStack{
                    Image(uiImage: UIImage(named: "sigmund.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: 0, y: -50)
                        .animation(.easeIn, value: 0)
                    //Match icon
                    Image(uiImage: UIImage(named: "superlike.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: 0, y: -50)
                        .animation(.easeIn, value: 0)
                    if(text3 != 0) {
                        Image(uiImage: UIImage(named: "popup.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 350, height: 450)
                            .padding()
                            .offset(x: 0, y: -50)
                            .animation(.easeIn, value: 0)
                    }
                    Image(uiImage: UIImage(named: "pasquale.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov1, y: -50)
                        .animation(.easeIn, value: mov1)
                    Image(uiImage: UIImage(named: "alessandro.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov2, y: -50)
                        .animation(.easeIn, value: mov2)
                    Image(uiImage: UIImage(named: "gabbibbo.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov3, y: -50)
                        .animation(.easeIn, value: mov3)
                }
                HStack {
                    Spacer()
                    //Decline button
                    if(fakenum != 0) {
                        Image(uiImage: UIImage(named: "X.png")!)
                            .frame(width: 80, height: 50)
                            .offset(x: -25, y: -25)
                            .onTapGesture {
                                if(fakenum == 0) {
                                    superLike = false
                                }
                                if(fakenum == 1) {
                                    mov1 = -500.0
                                    fakenum -= 1
                                    superLike = true
                                }
                                if(fakenum == 2) {
                                    mov2 = -500.0
                                    fakenum -= 1
                                }
                                if(fakenum == 3) {
                                    mov3 = -500.0
                                    fakenum -= 1
                                }
                            }
                        }
                        //Switch View
                        if(fakenum == 0) {
                            NavigationLink(destination: DialogueView(choice: $choice, text1: $text1, text2: $text2, text3: $text3)) {
                                    Text("Go to chat")
                                        .font(.system(size: 40))
                                        .fontWeight(.bold)
                                        .padding(10)
                                        .foregroundColor(.white)
                                        .background(Color.blue)
                                        .cornerRadius(10)
                                        .offset(x: 0, y: -40)
                            }
                            .onDisappear {
                                superLike = true
                            }
                        }
                        //Like button
                    else {
                        Image(uiImage: UIImage(named: "like.png")!)
                            .frame(width: 80, height: 50)
                            .offset(x: 25, y: -25)
                            .onTapGesture {
                                if(fakenum == 1) {
                                    mov1 = 500.0
                                    fakenum -= 1
                                }
                                if(fakenum == 2) {
                                    mov2 = 500.0
                                    fakenum -= 1
                                }
                                if(fakenum == 3) {
                                    mov3 = 500.0
                                    fakenum -= 1
                                }
                            }
                    }
                    Spacer()
                }
                Spacer()
            }
        }
    }
}

struct DialogueView: View {
    @Binding var choice: Int
    @Binding var text1: Int
    @Binding var text2: Int
    @Binding var text3: Int
    
    var body: some View {
        NavigationView{
            VStack {
                //Little photo on top of the screen
                Image(uiImage: UIImage(named: "freud cerchio.png")!)
                    .frame(width: 10, height: 10)
                    .offset(x: 0, y: 85)
                    .scaleEffect(0.3)
                    .ignoresSafeArea()
                Text("We are what we are 'cause we've been \nwhat we've been... Hello! What's up?")
                    .padding(10)
                    .foregroundColor(.white)
                    .background(Color.gray)
                    .cornerRadius(10)
                    .offset(x: -15, y: -155)
                if(text1 == 1) {
                    //First response to first question
                    Text("I downloaded Finder because I'm bored")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 10, y: -148)
                    Text("And how has it gone until now?")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -50, y: -141)
                }
                if(text1 == 2) {
                    //Second response to first question
                    Text("I donwloaded Finder to meet new people")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 10, y: -148)
                    Text("And how has it gone until now?")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -50, y: -141)
                }
                if(text2 == 1) {
                    //First response to second question
                    Text("This app sucks")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 102, y: -134)
                    Text("From error to error one discovers the truth. Which is your truth?")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -2, y: -127)
                }
                if(text2 == 2) {
                    //Second response to second question
                    Text("Not well...")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 125, y: -134)
                    Text("From error to error one discovers the truth. Which is your truth?")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -2, y: -127)
                }
                if(text3 == 1) {
                    //First response to third question
                    Text("It is better to meet people in person")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 30, y: -120)
                    Text("So no daddy issues? Not interested bye")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -15, y: -113)
                    Spacer()
                    Text("This user blocked you")
                        .padding(1)
                        .offset(x: 0, y: -20)
                }
                if(text3 == 2) {
                    //Second response to third question
                    Text("This app is for desperate people... \nI don't wanna be one of them.")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 30, y: -120)
                    Text("So no daddy issues? Not interested bye")
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -15, y: -113)
                    Spacer()
                    Text("This user blocked you")
                        .padding(1)
                        .offset(x: 0, y: -20)
                }
                Spacer()
                HStack{
                    if(choice == 1) {
                        //First choice to first dialogue
                        Button {
                            text1 = 1
                            choice += 1
                        } label: {
                            Text("I'm bored")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to first dialogue
                        Button {
                            text1 = 2
                            choice += 1
                        } label: {
                            Text("I'm horny")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                    if(choice == 2) {
                        //First choice to second dialogue
                        Button {
                            text2 = 1
                            choice += 1
                        } label: {
                            Text("Very bad")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to second dialogue
                        Button {
                            text2 = 2
                            choice += 1
                        } label: {
                            Text("Bad")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                    if(choice == 3) {
                        //First choice to third dialogue
                        Button {
                            text3 = 1
                            choice += 1
                        } label: {
                            Text("Awareness")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to third dialogue
                        Button {
                            text3 = 2
                            choice += 1
                        } label: {
                            Text("Fear")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                }
            }
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())

//: [Next Page](@next)
