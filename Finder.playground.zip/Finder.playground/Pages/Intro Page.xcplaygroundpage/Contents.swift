//Eugenio Raja
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    @State var but = false

    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "intro.png")!)
                .resizable()
                .scaledToFit()
                .frame(width: 250, height: 540)
                .ignoresSafeArea()
            if (but == false) {
                VStack{
                    Button {
                        but = true
                    } label: {
                        Text("INSTALL")
                            .font(.system(size: 10))
                            .padding(7)
                            .foregroundColor(.white)
                            .background(Color.blue)
                            .cornerRadius(10)
                            .position(x: 118, y: 130)
                    }
                Spacer()
                }
            }
            else {
                HStack {
                    Text("OPEN")
                        .font(.system(size: 10))
                        .padding(7)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .position(x: 115, y: 130)
                    Text("and go to the\nnext page")
                        .font(.system(size: 8))
                        .padding(1)
                        .position(x: 38, y: 129)
                }
            }
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
 
//: [Next Page](@next)
