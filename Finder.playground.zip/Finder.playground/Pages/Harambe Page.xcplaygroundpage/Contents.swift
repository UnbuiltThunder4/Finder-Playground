//: [Previous Page](@previous)

//Andrea Autiero
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    @State var mov = 0.0
    @State var mov1 = 0.0
    @State var mov2 = 0.0
    @State var mov3 = 0.0
    @State var fakenum = 3
    @State var canmatch = false
    @State var didmatch = false
    @State private var choice: Int = 1
    @State private var text1: Int = 0
    @State private var text2: Int = 0
    @State private var text3: Int = 0
    
    var body: some View {
        NavigationView{
            VStack {
                Image(uiImage: UIImage(named: "banner.png")!)
                    .frame(width: 10, height: 10)
                    .offset(x: 0, y: 49)
                    .scaleEffect(0.45)
                    .ignoresSafeArea()
                //Profiles
                ZStack{
                    Image(uiImage: UIImage(named: "antonino.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: 0, y: -50)
                    Image(uiImage: UIImage(named: "next.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: 0, y: -50)
                    Image(uiImage: UIImage(named: "harambe.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov, y: -50)
                        .animation(.easeIn, value: mov)
                    //Match icon
                    if(didmatch == true) {
                        Image(uiImage: UIImage(named: "match.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 350, height: 450)
                            .padding()
                            .offset(x: mov, y: -50)
                            .animation(.easeIn, value: mov)
                    }
                    Image(uiImage: UIImage(named: "andre.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov1, y: -50)
                        .animation(.easeIn, value: mov1)
                    Image(uiImage: UIImage(named: "brumotti.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov2, y: -50)
                        .animation(.easeIn, value: mov2)
                    Image(uiImage: UIImage(named: "grata.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 450)
                        .padding()
                        .offset(x: mov3, y: -50)
                        .animation(.easeIn, value: mov3)
                }
                HStack {
                    Spacer()
                    //Decline button
                    Image(uiImage: UIImage(named: "X.png")!)
                        .frame(width: 80, height: 50)
                        .offset(x: -25, y: -25)
                        .onTapGesture {
                            if(fakenum == 0) {
                                mov = -500.0
                                canmatch = false
                                didmatch = false
                            }
                            if(fakenum == 1) {
                                mov1 = -500.0
                                fakenum -= 1
                                canmatch = true
                            }
                            if(fakenum == 2) {
                                mov2 = -500.0
                                fakenum -= 1
                            }
                            if(fakenum == 3) {
                                mov3 = -500.0
                                fakenum -= 1
                            }
                        }
                    //Switch View
                    if(canmatch == true) {
                        NavigationLink(destination: DialogueView(choice: $choice, text1: $text1, text2: $text2, text3: $text3)) {
                            Image(uiImage: UIImage(named: "like.png")!)
                                .frame(width: 80, height: 50)
                                .offset(x: 25, y: -25)
                        }
                        .onDisappear {
                            didmatch = true
                        }
                    }
                    else {
                        //Like button
                        Image(uiImage: UIImage(named: "like.png")!)
                            .frame(width: 80, height: 50)
                            .offset(x: 25, y: -25)
                            .onTapGesture {
                                if(fakenum == 1) {
                                    mov1 = 500.0
                                    fakenum -= 1
                                    canmatch = true
                                }
                                if(fakenum == 2) {
                                    mov2 = 500.0
                                    fakenum -= 1
                                }
                                if(fakenum == 3) {
                                    mov3 = 500.0
                                    fakenum -= 1
                                }
                            }
                    }
                    Spacer()
                }
                Spacer()
            }
        }
    }
}

struct DialogueView: View {
    @Binding var choice: Int
    @Binding var text1: Int
    @Binding var text2: Int
    @Binding var text3: Int
    
    var body: some View {
        NavigationView{
            VStack {
                //Little photo on top of the screen
                Image(uiImage: UIImage(named: "harambe circolare.png")!)
                    .frame(width: 10, height: 10)
                    .offset(x: 0, y: 85)
                    .scaleEffect(0.3)
                    .ignoresSafeArea()
                ZStack {
                    Image(uiImage: UIImage(named: "banana.png")!)
                        .padding(7)
                        .frame(width: 180, height: 200)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -80, y: -158)
                    Text("mhh you pretty.")
                        .foregroundColor(.white)
                        .offset(x: -96, y: -72)
                        .ignoresSafeArea()
                }
                if(text1 == 1) {
                    //First response to first question
                    Text("...")
                        .padding(7)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 150, y: -152)
                    Text("banana is mature")
                        .padding(7)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -90, y: -148)
                }
                if(text1 == 2) {
                    //Second response to first question
                    Text("You blocked this user")
                        .padding(1)
                        .offset(x: 0, y: -5)
                }
                if(text2 == 1) {
                    //First response to second question
                    Text("why you do this?")
                        .padding(7)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .offset(x: 92, y: -142)
                    Text("Eat banana babe")
                        .padding(7)
                        .foregroundColor(.white)
                        .background(Color.gray)
                        .cornerRadius(10)
                        .offset(x: -88, y: -138)
                }
                if(text2 == 2) {
                    //Second response to second question
                    Text("You blocked this user")
                        .padding(1)
                        .offset(x: 0, y: -5)
                }
                if(text3 == 2) {
                    //Second response to third question
                    Text("You blocked this user")
                        .padding(1)
                        .offset(x: 0, y: -5)
                }
                else { //First response to third question (simple if didn't work???)
                    if(text3 != 0) {
                        Text("Hope I never harrassed anyone like this")
                            .padding(7)
                            .foregroundColor(.white)
                            .background(Color.blue)
                            .cornerRadius(10)
                            .offset(x: 8, y: -132)
                        Text("You blocked this user")
                            .padding(1)
                            .offset(x: 0, y: -5)
                    }
                }
                Spacer()
                HStack{
                    if(choice == 1) {
                        //First choice to first dialogue
                        Button {
                            text1 = 1
                            choice += 1
                        } label: {
                            Text("...")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to first dialogue
                        Button {
                            text1 = 2
                            choice = 5
                        } label: {
                            Text("Block him ")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                    if(choice == 2) {
                        //First choice to second dialogue
                        Button {
                            text2 = 1
                            choice += 1
                        } label: {
                            Text("Question him")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to second dialogue
                        Button {
                            text2 = 2
                            choice = 5
                        } label: {
                            Text("Block him")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                    if(choice == 3) {
                        //First choice to third dialogue
                        Button {
                            text3 = 1
                            choice += 1
                        } label: {
                            Text("Reflection")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                        //Second choice to third dialogue
                        Button {
                            text3 = 2
                            choice = 5
                        } label: {
                            Text("Block him")
                                .padding(10)
                                .foregroundColor(.white)
                                .background(Color.black)
                                .cornerRadius(10)
                                .offset(x: 0, y: -10)
                        }
                    }
                }
            }
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())

//: [Next Page](@next)
