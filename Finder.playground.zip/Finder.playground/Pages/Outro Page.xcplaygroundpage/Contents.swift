//: [Previous Page](@previous)

//Eugenio Raja
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    @State var stars = 0

    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "review.PNG")!)
                .resizable()
                .scaledToFit()
                .frame(width: 250, height: 540)
                .ignoresSafeArea()
            if(stars != 0) {
                Image(uiImage: UIImage(named: "whitespace.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250, height: 100)
                    .ignoresSafeArea()
                    .offset(x: 0, y: -115)
            }
            switch stars {
            case 1:
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -43, y: -193)
                Text("Finder sucks. Worst experience in my life: too many freaks and charity chases. Uninstalled for the sake of my mental health.")
                    .padding(10)
                    .font(.system(size: 10))
                    .offset(x: 0, y: -120)
            case 2:
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -43, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -21, y: -193)
                Text("I don't wanna date freaks. Uninstalled instantly. Meeting new people should remain an offline experience.")
                    .padding(10)
                    .font(.system(size: 10))
                    .offset(x: 0, y: -120)
            case 3:
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -43, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -21, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: 0, y: -193)
                Text("Finder made me realize that I need to meet new people. Real people. Interesting app though... If you wanna take a laugh at the freaks online.")
                    .padding(10)
                    .font(.system(size: 10))
                    .offset(x: 0, y: -120)
            case 4:
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -43, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -21, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: 0, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: 21, y: -193)
                Text("I had the chance to chat with persons I would never met offline. How Lucky! Thanks to Finder now I know which people I need to avoid in real life.")
                    .padding(10)
                    .font(.system(size: 10))
                    .offset(x: 0, y: -120)
            case 5:
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -43, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: -21, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: 0, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: 21, y: -193)
                Image(uiImage: UIImage(named: "star.png")!)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.05)
                    .ignoresSafeArea()
                    .offset(x: 43, y: -193)
                Text("Worst dating app ever but at least I took a big laugh at every freak jumping in my chat.")
                    .padding(10)
                    .font(.system(size: 10))
                    .offset(x: 0, y: -120)
            default:
                Text("")
                    .padding(10)
                    .font(.system(size: 10))
                    .offset(x: 0, y: -10)
            }
            VStack {
                Spacer()
                HStack {
                    Button {
                        stars = 1
                    } label: {
                        Text("1 star")
                            .padding(10)
                            .font(.system(size: 10))
                            .foregroundColor(.white)
                            .background(Color.black)
                            .cornerRadius(10)
                            .offset(x: 0, y: -10)
                    }
                    Button {
                        stars = 2
                    } label: {
                        Text("2 stars")
                            .padding(10)
                            .font(.system(size: 10))
                            .foregroundColor(.white)
                            .background(Color.black)
                            .cornerRadius(10)
                            .offset(x: 0, y: -10)
                    }
                }
                HStack {
                    Button {
                        stars = 3
                    } label: {
                        Text("3 stars")
                            .padding(10)
                            .font(.system(size: 10))
                            .foregroundColor(.white)
                            .background(Color.black)
                            .cornerRadius(10)
                            .offset(x: 0, y: -10)
                    }
                    Button {
                        stars = 4
                    } label: {
                        Text("4 stars")
                            .padding(10)
                            .font(.system(size: 10))
                            .foregroundColor(.white)
                            .background(Color.black)
                            .cornerRadius(10)
                            .offset(x: 0, y: -10)
                    }
                    Button {
                        stars = 5
                    } label: {
                        Text("5 stars")
                            .padding(10)
                            .font(.system(size: 10))
                            .foregroundColor(.white)
                            .background(Color.black)
                            .cornerRadius(10)
                            .offset(x: 0, y: -10)
                    }
                }
            }
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
